import axios from 'axios';

const API_URL = 'http://localhost:5000/api';

// Register a customer
const registerCustomer = (data) => axios.post(`${API_URL}/customers/register`, data);

// Login a customer
const loginCustomer = (data) => axios.post(`${API_URL}/customers/login`, data);

// Make a payment (Updated URL for making a payment)
const makePayment = (token, data) => axios.post(`${API_URL}/customers/make-payment`, data, {
    headers: { Authorization: `Bearer ${token}` }
});

// Login an employee
const loginEmployee = (data) => axios.post(`${API_URL}/employees/login`, data);

// Get payments (for employee dashboard)
const getPayments = (token) => axios.get(`${API_URL}/customers/payments`, {
    headers: { Authorization: `Bearer ${token}` }
});

// Verify payment (for employee verification of payment)
const verifyPayment = (token, paymentId) => axios.post(`${API_URL}/employees/verify-payment/${paymentId}`, {}, {
    headers: { Authorization: `Bearer ${token}` }
});

export { registerCustomer, loginCustomer, makePayment, loginEmployee, getPayments, verifyPayment };
