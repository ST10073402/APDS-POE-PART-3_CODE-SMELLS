import React, { useState } from 'react';
import { makePayment } from '../services/api';

const Payment = () => {
    const [paymentData, setPaymentData] = useState({
        amount: '', 
        currency: 'ZAR', 
        paymentProvider: 'SWIFT',  // Set payment provider to 'SWIFT' as needed
        recipientAccountNumber: '', 
        recipientSWIFTCode: ''
    });

    const handleChange = (e) => {
        setPaymentData({ ...paymentData, [e.target.id]: e.target.value });
    };

    const handleSubmit = async (e) => {
        e.preventDefault();
        const token = localStorage.getItem('customerToken');

        try {
            // Logging the payment data for debugging purposes
            console.log("Payment Data: ", paymentData);

            // Call to the API function to make the payment
            const response = await makePayment(token, paymentData);

            if (response.data.success) {
                alert('Payment initiated successfully!');
            } else {
                alert('Payment failed: ' + response.data.message);
            }
        } catch (error) {
            console.error('Payment error:', error);
            alert('Payment error: ' + (error.response?.data?.message || error.message || 'Unknown error'));
        }
    };

    return (
        <form onSubmit={handleSubmit} style={styles.form}>
            <h3 style={styles.header}>Make a Payment</h3>
            <input 
                type="number" 
                id="amount" 
                onChange={handleChange} 
                placeholder="Amount" 
                required 
                style={styles.input} 
            />
            <select 
                id="currency" 
                onChange={handleChange} 
                value={paymentData.currency} 
                style={styles.input}
            >
                <option value="ZAR">ZAR</option>
                <option value="USD">USD</option>
                <option value="EUR">EUR</option>
            </select>
            <input 
                type="text" 
                id="recipientAccountNumber" 
                onChange={handleChange} 
                placeholder="Recipient Account Number" 
                required 
                style={styles.input} 
            />
            <input 
                type="text" 
                id="recipientSWIFTCode" 
                onChange={handleChange} 
                placeholder="Recipient SWIFT Code" 
                style={styles.input} 
            />
            <button type="submit" style={styles.button}>Pay Now</button>
        </form>
    );
};

const styles = {
    form: {
        display: 'flex',
        flexDirection: 'column',
        maxWidth: '300px',
        margin: '0 auto',
        padding: '20px',
        border: '1px solid #ccc',
        borderRadius: '5px',
        backgroundColor: '#f9f9f9'
    },
    header: {
        textAlign: 'center',
        marginBottom: '15px',
        color: '#333'
    },
    input: {
        marginBottom: '10px',
        padding: '8px',
        fontSize: '16px',
        borderRadius: '4px',
        border: '1px solid #ccc'
    },
    button: {
        padding: '10px',
        backgroundColor: '#4CAF50',
        color: '#fff',
        border: 'none',
        borderRadius: '4px',
        cursor: 'pointer'
    }
};

export default Payment;
