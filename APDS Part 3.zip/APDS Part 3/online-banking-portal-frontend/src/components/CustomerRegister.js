import React, { useState } from 'react';
import { registerCustomer } from '../services/api';

const CustomerRegister = () => {
    const [formData, setFormData] = useState({
        fullName: '', idNumber: '', accountNumber: '', password: ''
    });

    const handleChange = (e) => {
        setFormData({ ...formData, [e.target.id]: e.target.value });
    };

    const handleSubmit = async (e) => {
        e.preventDefault();
        try {
            await registerCustomer(formData);
            alert('Customer registered successfully!');
        } catch (error) {
            alert('Registration error: ' + error.response.data.message);
        }
    };

    return (
        <form onSubmit={handleSubmit} style={styles.form}>
            <h3 style={styles.header}>Customer Registration</h3>
            <input type="text" id="fullName" onChange={handleChange} placeholder="Full Name" required style={styles.input} />
            <input type="text" id="idNumber" onChange={handleChange} placeholder="ID Number" required style={styles.input} />
            <input type="text" id="accountNumber" onChange={handleChange} placeholder="Account Number" required style={styles.input} />
            <input type="password" id="password" onChange={handleChange} placeholder="Password" required style={styles.input} />
            <button type="submit" style={styles.button}>Register</button>
        </form>
    );
};

const styles = {
    form: { display: 'flex', flexDirection: 'column', maxWidth: '300px', margin: '0 auto', padding: '20px', border: '1px solid #ccc', borderRadius: '5px', backgroundColor: '#f9f9f9' },
    header: { textAlign: 'center', marginBottom: '15px', color: '#333' },
    input: { marginBottom: '10px', padding: '8px', fontSize: '16px', borderRadius: '4px', border: '1px solid #ccc' },
    button: { padding: '10px', backgroundColor: '#4CAF50', color: '#fff', border: 'none', borderRadius: '4px', cursor: 'pointer' }
};

export default CustomerRegister;
