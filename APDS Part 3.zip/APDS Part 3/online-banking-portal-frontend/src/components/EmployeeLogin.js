import React, { useState } from 'react';
import { useNavigate } from 'react-router-dom';
import { loginEmployee } from '../services/api';

const EmployeeLogin = ({ onLogin }) => {
    const [formData, setFormData] = useState({ username: '', password: '' });
    const navigate = useNavigate();

    const handleChange = (e) => {
        setFormData({ ...formData, [e.target.id]: e.target.value });
    };

    const handleSubmit = async (e) => {
        e.preventDefault();
        try {
            const response = await loginEmployee(formData);
            localStorage.setItem('employeeToken', response.data.token);
            onLogin();
            navigate('/employee/dashboard');  // Redirect to the Dashboard after successful login
        } catch (error) {
            alert('Login error: ' + error.response.data.message);
        }
    };

    return (
        <form onSubmit={handleSubmit} style={styles.form}>
            <h3 style={styles.header}>Employee Login</h3>
            <input type="text" id="username" onChange={handleChange} placeholder="Username" required style={styles.input} />
            <input type="password" id="password" onChange={handleChange} placeholder="Password" required style={styles.input} />
            <button type="submit" style={styles.button}>Login</button>
        </form>
    );
};

const styles = {
    form: { display: 'flex', flexDirection: 'column', maxWidth: '300px', margin: '0 auto', padding: '20px', border: '1px solid #ccc', borderRadius: '5px', backgroundColor: '#f9f9f9' },
    header: { textAlign: 'center', marginBottom: '15px', color: '#333' },
    input: { marginBottom: '10px', padding: '8px', fontSize: '16px', borderRadius: '4px', border: '1px solid #ccc' },
    button: { padding: '10px', backgroundColor: '#4CAF50', color: '#fff', border: 'none', borderRadius: '4px', cursor: 'pointer' }
};

export default EmployeeLogin;
