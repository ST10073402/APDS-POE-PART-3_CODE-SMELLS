import React, { useState, useEffect } from 'react';
import { getPayments } from '../services/api';

const Dashboard = () => {
    const [payments, setPayments] = useState([]);

    useEffect(() => {
        const fetchPayments = async () => {
            try {
                const response = await getPayments();  
                setPayments(response.data);
            } catch (error) {
                alert('Error fetching payments: ' + (error.response?.data?.message || error.message));
            }
        };
        fetchPayments();
    }, []);

    const handleVerify = (paymentId) => {
        
        setPayments(prevPayments =>
            prevPayments.map(payment =>
                payment._id === paymentId ? { ...payment, verified: true } : payment
            )
        );
        alert('Payment verified successfully!');
    };

    return (
        <div style={styles.container}>
            <h3 style={styles.header}>Payment Dashboard</h3>
            <table style={styles.table}>
                <thead>
                    <tr>
                        <th style={styles.tableHeader}>Account Number</th>
                        <th style={styles.tableHeader}>Amount</th>
                        <th style={styles.tableHeader}>Currency</th>
                        <th style={styles.tableHeader}>SWIFT Code</th>
                        <th style={styles.tableHeader}>Status</th>
                        <th style={styles.tableHeader}>Action</th>
                    </tr>
                </thead>
                <tbody>
                    {payments.map(payment => (
                        <tr key={payment._id} style={styles.tableRow}>
                            <td style={styles.tableCell}>{payment.recipientAccountNumber}</td>
                            <td style={styles.tableCell}>{payment.amount}</td>
                            <td style={styles.tableCell}>{payment.currency}</td>
                            <td style={styles.tableCell}>{payment.recipientSWIFTCode}</td>
                            <td style={styles.tableCell}>{payment.verified ? 'Verified' : 'Pending'}</td>
                            <td style={styles.tableCell}>
                                {!payment.verified && (
                                    <button onClick={() => handleVerify(payment._id)} style={styles.verifyButton}>
                                        Verify
                                    </button>
                                )}
                            </td>
                        </tr>
                    ))}
                </tbody>
            </table>
        </div>
    );
};

const styles = {
    container: { maxWidth: '800px', margin: '0 auto', padding: '20px', backgroundColor: '#f9f9f9', borderRadius: '5px' },
    header: { textAlign: 'center', color: '#333', marginBottom: '20px' },
    table: { width: '100%', borderCollapse: 'collapse' },
    tableHeader: { backgroundColor: '#4CAF50', color: 'white', padding: '10px', border: '1px solid #ddd' },
    tableRow: { backgroundColor: '#f9f9f9' },
    tableCell: { padding: '10px', border: '1px solid #ddd', textAlign: 'center' },
    verifyButton: { padding: '5px 10px', backgroundColor: '#4CAF50', color: '#fff', border: 'none', borderRadius: '4px', cursor: 'pointer' }
};

export default Dashboard;
