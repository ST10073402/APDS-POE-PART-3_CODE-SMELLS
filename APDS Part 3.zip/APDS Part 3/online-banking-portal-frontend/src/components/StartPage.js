import React from 'react';
import { useNavigate } from 'react-router-dom';

function StartPage() {
    const navigate = useNavigate();

    const handleCustomerClick = () => {
        navigate('/customer/login');
    };

    const handleEmployeeClick = () => {
        navigate('/employee/login');
    };

    return (
        <div style={styles.container}>
            <h1 style={styles.heading}>Welcome to the Payment Portal</h1>
            <div style={styles.buttonContainer}>
                <button style={styles.button} onClick={handleCustomerClick}>Customer</button>
                <button style={styles.button} onClick={handleEmployeeClick}>Employee</button>
            </div>
        </div>
    );
}

const styles = {
    container: {
        display: 'flex',
        flexDirection: 'column',
        alignItems: 'center',
        justifyContent: 'center',
        height: '100vh',
        backgroundColor: '#f0f4f8',
    },
    heading: {
        fontSize: '2em',
        color: '#333',
        marginBottom: '20px',
    },
    buttonContainer: {
        display: 'flex',
        gap: '20px',
    },
    button: {
        padding: '10px 20px',
        fontSize: '1em',
        color: '#fff',
        backgroundColor: '#007bff',
        border: 'none',
        borderRadius: '5px',
        cursor: 'pointer',
    },
};

export default StartPage;
