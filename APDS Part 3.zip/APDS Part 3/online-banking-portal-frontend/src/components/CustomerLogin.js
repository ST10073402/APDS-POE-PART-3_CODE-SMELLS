import React, { useState } from 'react';
import { useNavigate } from 'react-router-dom';
import { loginCustomer } from '../services/api';

const CustomerLogin = ({ onLogin }) => {
    const [formData, setFormData] = useState({ accountNumber: '', password: '' });
    const navigate = useNavigate();

    const handleChange = (e) => {
        setFormData({ ...formData, [e.target.id]: e.target.value });
    };

    const handleSubmit = async (e) => {
        e.preventDefault();
        try {
            const response = await loginCustomer(formData);
            localStorage.setItem('customerToken', response.data.token);
            onLogin();  // Sets the customer as logged in
            navigate('/customer/payment');  // Redirects to the Payment page
        } catch (error) {
            alert('Login error: ' + error.response.data.message);
        }
    };

    const handleRegisterClick = () => {
        navigate('/customer/register');  // Redirects to the CustomerRegister page
    };

    return (
        <form onSubmit={handleSubmit} style={styles.form}>
            <h3 style={styles.header}>Customer Login</h3>
            <input type="text" id="accountNumber" onChange={handleChange} placeholder="Account Number" required style={styles.input} />
            <input type="password" id="password" onChange={handleChange} placeholder="Password" required style={styles.input} />
            <button type="submit" style={styles.button}>Login</button>
            <button type="button" onClick={handleRegisterClick} style={styles.registerButton}>Register</button>
        </form>
    );
};

const styles = {
    form: { 
        display: 'flex', 
        flexDirection: 'column', 
        maxWidth: '300px', 
        margin: '0 auto', 
        padding: '20px', 
        border: '1px solid #ccc', 
        borderRadius: '5px', 
        backgroundColor: '#f9f9f9' 
    },
    header: { 
        textAlign: 'center', 
        marginBottom: '15px', 
        color: '#333' 
    },
    input: { 
        marginBottom: '10px', 
        padding: '8px', 
        fontSize: '16px', 
        borderRadius: '4px', 
        border: '1px solid #ccc' 
    },
    button: { 
        padding: '10px', 
        backgroundColor: '#4CAF50', 
        color: '#fff', 
        border: 'none', 
        borderRadius: '4px', 
        cursor: 'pointer' 
    },
    registerButton: { 
        padding: '10px', 
        backgroundColor: '#2196F3', 
        color: '#fff', 
        border: 'none', 
        borderRadius: '4px', 
        cursor: 'pointer', 
        marginTop: '10px' 
    }
};

export default CustomerLogin;
