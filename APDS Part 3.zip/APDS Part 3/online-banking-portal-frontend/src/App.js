import React, { useState } from 'react';
import { BrowserRouter as Router, Routes, Route, Navigate } from 'react-router-dom';
import CustomerRegister from './components/CustomerRegister';
import CustomerLogin from './components/CustomerLogin';
import Payment from './components/Payment';
import EmployeeLogin from './components/EmployeeLogin';
import Dashboard from './components/Dashboard';
import StartPage from './components/StartPage';

function App() {
    const [customerLoggedIn, setCustomerLoggedIn] = useState(false);
    const [employeeLoggedIn, setEmployeeLoggedIn] = useState(false);

    return (
        <Router>
            <Routes>
                <Route path="/" element={<StartPage />} />
                <Route path="/customer/register" element={<CustomerRegister />} />
                <Route path="/customer/login" element={<CustomerLogin onLogin={() => setCustomerLoggedIn(true)} />} />
                <Route path="/customer/payment" element={customerLoggedIn ? <Payment /> : <Navigate to="/customer/login" />} />
                
                <Route path="/employee/login" element={<EmployeeLogin onLogin={() => setEmployeeLoggedIn(true)} />} />
                <Route path="/employee/dashboard" element={employeeLoggedIn ? <Dashboard /> : <Navigate to="/employee/login" />} />
            </Routes>
        </Router>
    );
}

export default App;
